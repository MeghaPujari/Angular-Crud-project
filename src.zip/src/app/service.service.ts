import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';

import { Observable } from 'rxjs';
import { Employee } from './model/employee';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(public http:HttpClient) { }
  url:string="http://localhost:3001";
  emp:Employee;
  EmployeeSave(emp:Employee)
  {
      return this.http.post<Employee>(this.url+"/getAllData",emp);
  }

  EmployeeGetData():Observable<Employee[]>
  {
     return this.http.get<Employee[]>(this.url+"/getAllData");
  }
updateEmployeeData(emp:Employee,eid:number)
  {
      return this.http.put(this.url+"/getAllData/"+eid,emp);
  }
 deleteEmployeeData(eid:number)
 {
     return this.http.delete(this.url+"/getAllData/"+eid);
 }


}