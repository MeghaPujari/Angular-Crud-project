export class Employee {
    id:number;
    name:string;
    mob:String;
    addr:string;
}
