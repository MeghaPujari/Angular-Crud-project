import { Component,OnInit } from '@angular/core';
import { Employee } from '../model/employee';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private cs:ServiceService) { }

  emp!:Employee[];

  ngOnInit(): void {

    this.GetAllData();
  }
  GetAllData(){
    this.cs.EmployeeGetData().subscribe(list =>{

      this.emp=list
    })
  }
  deleteDataById(eid :number)
  {
  this.cs.deleteEmployeeData(eid).subscribe( data =>{
  console.log(data);
    this.GetAllData();
  //window.location.reload();
})
  }
}
