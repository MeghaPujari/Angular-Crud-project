import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {Employee} from '../model/employee';
import { ServiceService } from '../service.service';
import { getLocaleDateFormat, getLocaleDateTimeFormat } from '@angular/common';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private fb:FormBuilder,public cs:ServiceService) { }
  emp!:Employee[]
  empForm!:FormGroup;
  empObj={
    id:"",
    name:"",
    mob:"",
    addr:""
  }
  ngOnInit(): void {


    this.empForm=this.fb.group({
      // id:[''],
      name:['',[Validators.required]],
      addr:['',[Validators.required]],
      mob:['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]]
   
    })
    this.getAllEmployeeData();
   
  }

   /* onSubmit()
  {
    console.log("invalid");
   //if(this.empForm.valid)
   // {
      console.log("valid");
      console.log(this.empForm.value);
    this.cs.EmployeeSave(this.empForm.value).subscribe();
    window.location.reload();
   // }
 }  */
submitdata(emp:Employee,EmpId:any){
    console.log("id" + EmpId);
  if(this.empForm.valid){
    if(EmpId==null || EmpId == "")
    {
      console.log("add");
      this.cs.EmployeeSave(emp).subscribe( data =>{
      this.getAllEmployeeData();
      //window.location.reload();
      })
    }
    else{
      console.log("update");
      console.log(emp);
      this.cs.updateEmployeeData(emp,EmpId).subscribe( data =>{
        this.getAllEmployeeData();
        //window.location.reload();
        })
      
    }
  }
}
 getAllEmployeeData(){
  this.cs.EmployeeGetData().subscribe(list =>{

    this.emp=list
  })
}
  
EditEmp(emp:any){
  console.log(emp);
  this.empObj = emp;
}

deleteDataById(eid :number)
{
this.cs.deleteEmployeeData(eid).subscribe( data =>{
console.log(data);
  this.getAllEmployeeData();

})
}

reset(){
  //this.emp=Object.assign({},null);
  this.empForm.reset();
}

}






